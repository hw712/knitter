
"""
HISTORY
    Version 0.5.0:
            - Support Python 3.5 and plus. Python 2.7 is deprecated.
            - Deprecate the multi-threading feature.
            - Rewrite all modules, especially the configure methods.
            - Update HTML report.
"""
__version__ = "0.5.0"
