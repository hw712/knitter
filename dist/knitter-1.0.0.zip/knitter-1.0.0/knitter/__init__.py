
"""
HISTORY
    Version 1.0.0:
            - Support Python 3.5 and plus. Python 2.7 is deprecated.
            - Deprecated the multi-threading feature.
            - Rewrote all implementations of executor.
            - Updated HTML report.
            - Updated WebElement methods.
"""
__version__ = "1.0.0"
