﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-



BROWSER = None

PROJECT_PATH = ""

CASE_START_TIME = ""
CASE_STOP_TIME  = ""

CASE_NAME = ""
CASE_PASS = ""

MODULE_NAME = ""

TEST_URL = ""

RUNNING_BROWSER  = "Firefox"
TESTING_BROWSERS = "Firefox|IE"

EXCEL_REPORT_DATA = []




'''
import os

browser = None

root_path    = os.path.split(os.path.realpath(__file__))[0]
project_path = root_path
'''



if __name__ == '__main__':
    print PROJECT_PATH
