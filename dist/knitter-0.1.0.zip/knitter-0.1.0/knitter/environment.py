# -*- coding: utf-8 -*-


# Driver of web browser, such as: webdriver.Firefox()
BROWSER             = None


# Root path of the testing project.
PROJECT_PATH        = ""


# Test Case/Module variables.
CASE_START_TIME     = ""
CASE_STOP_TIME      = ""
CASE_NAME           = ""
CASE_PASS           = ""

MODULE_NAME         = ""


# URL of the testing page.
TEST_URL            = ""


# RUNNING_BROWSER is one of TESTING_BROWSERS
RUNNING_BROWSER     = "Firefox"
TESTING_BROWSERS    = "Firefox|IE"


# Data of test result, for generate report in excel.
EXCEL_REPORT_DATA   = []














