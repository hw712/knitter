Knitter ['nitə]
--------------------------------------------

 A Web Automation Test Framework Based on Selenium WebDriver. (Python 3, Selenium) 


Documents
--------------------------------------------

- https://outsidematrix.com/note/QA/Knitter.html

- https://outsidematrix.com/note/QA/Knitter-Tutorial.html


Example
--------------------------------------------

- https://github.com/hw712/knitter-example


License
--------------------------------------------

- BSD License








